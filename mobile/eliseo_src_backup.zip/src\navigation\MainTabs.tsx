import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

import type {MainTabParamList} from '../types/navigation';
import {AnimatedTabBar} from '../components/AnimatedTabBar';
import {CommunitiesScreen} from '../screens/CommunitiesScreen';
import {DriveScreen} from '../screens/DriveScreen';
import {FeedScreen} from '../screens/FeedScreen';
import {MessagesScreen} from '../screens/MessagesScreen';
import {ProfileScreen} from '../screens/ProfileScreen';

const Tab = createBottomTabNavigator<MainTabParamList>();

export function MainTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Feed"
      tabBar={props => <AnimatedTabBar {...props} />}
      screenOptions={{
        headerShown: false,
        lazy: true,
        sceneStyle: {
          backgroundColor: '#070B12',
        },
      }}
    >
      <Tab.Screen name="Feed" component={FeedScreen} />
      <Tab.Screen name="Communities" component={CommunitiesScreen} />
      <Tab.Screen name="Messages" component={MessagesScreen} />
      <Tab.Screen name="Drive" component={DriveScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
