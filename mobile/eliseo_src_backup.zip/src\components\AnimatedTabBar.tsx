import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import type {BottomTabBarProps} from '@react-navigation/bottom-tabs';
import {
  Folder,
  Home,
  MessageCircle,
  UserRound,
  Users,
} from 'lucide-react-native';
import Animated, {
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import {colors, motion, radii} from '../theme';
import {NativePressable} from './NativePressable';

const icons = {
  Feed: Home,
  Communities: Users,
  Messages: MessageCircle,
  Drive: Folder,
  Profile: UserRound,
} as const;

const labels = {
  Feed: 'Feed',
  Communities: 'Comunidades',
  Messages: 'Mensagens',
  Drive: 'Pastas',
  Profile: 'Perfil',
} as const;

function TabItem({
  routeName,
  focused,
  onPress,
}: {
  routeName: keyof typeof icons;
  focused: boolean;
  onPress: () => void;
}) {
  const Icon = icons[routeName];

  const iconStyle = useAnimatedStyle(() => ({
    transform: [
      {
        translateY: withTiming(focused ? -2 : 0, {
          duration: motion.quick,
        }),
      },
    ],
  }));

  return (
    <NativePressable haptic onPress={onPress} style={styles.item}>
      <View style={styles.itemInner}>
        <Animated.View
          style={[
            styles.iconWrap,
            focused && styles.iconWrapFocused,
            iconStyle,
          ]}
        >
          <Icon
            size={21}
            strokeWidth={focused ? 2.4 : 2}
            color={focused ? colors.blue : colors.muted}
          />
        </Animated.View>

        <Text
          numberOfLines={1}
          style={[
            styles.label,
            focused && styles.labelFocused,
          ]}
        >
          {labels[routeName]}
        </Text>
      </View>
    </NativePressable>
  );
}

export function AnimatedTabBar({
  state,
  descriptors,
  navigation,
}: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.root,
        {
          paddingBottom: Math.max(insets.bottom, 8),
        },
      ]}
    >
      <View style={styles.bar}>
        {state.routes.map((route, index) => {
          const focused = state.index === index;
          const routeName = route.name as keyof typeof icons;

          if (!icons[routeName]) {
            return null;
          }

          return (
            <TabItem
              key={route.key}
              routeName={routeName}
              focused={focused}
              onPress={() => {
                const event = navigation.emit({
                  type: 'tabPress',
                  target: route.key,
                  canPreventDefault: true,
                });

                if (!focused && !event.defaultPrevented) {
                  navigation.navigate(route.name, route.params);
                }
              }}
            />
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    backgroundColor: 'transparent',
    paddingHorizontal: 10,
    paddingTop: 6,
  },
  bar: {
    minHeight: 68,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0D141F',
    borderRadius: 20,
    paddingHorizontal: 4,
    paddingVertical: 5,
    shadowColor: colors.black,
    shadowOpacity: 0.28,
    shadowRadius: 20,
    shadowOffset: {width: 0, height: 12},
    elevation: 16,
  },
  item: {
    flex: 1,
    minWidth: 0,
    height: 58,
  },
  itemInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
  },
  iconWrap: {
    width: 36,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.pill,
  },
  iconWrapFocused: {
    backgroundColor: 'rgba(66,169,255,0.11)',
  },
  label: {
    color: colors.faint,
    fontSize: 9,
    fontWeight: '650',
  },
  labelFocused: {
    color: colors.textSoft,
  },
});
